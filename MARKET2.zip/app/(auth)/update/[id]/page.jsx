import React from "react";
import Updateform from "../Updateform";
import Header from "../../../../components/header/Header";

export const Page = () => {
  return (
    <div>
      <Header />

      <Updateform />
    </div>
  );
};
export default Page;
