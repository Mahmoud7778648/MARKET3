import React from "react";
import SigninForm from "./signinform";

const SignIn = () => {
  return <SigninForm />;
};
export default SignIn;
