import React from "react";
import { Header } from "../../../components/header/Header";
import Signupform from "./signupform";

const SignUp = () => {
  return (
    <div>
      <Signupform />
    </div>
  );
};
export default SignUp;
