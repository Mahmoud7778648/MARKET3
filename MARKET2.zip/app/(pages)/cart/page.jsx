import React from "react";
import { CartForm } from "./cartform";

export const Page = () => {
  return (
    <div>
      <CartForm />
    </div>
  );
};
export default Page;
